#!/bin/sh
fsmd5="321ec2ff2e27d1aa5277b9a0c81a4a3b"
kernelmd5="869bb3f9cabed36949681c4a4071ab13"
bootmd5="60d3e4ad970a3a9ca874ad5cd9bbf17e"
gphymd5="971b7eb3e686d47e51bf6ffa2b83f3a4"
ubootmd5="4aaa7630d4802757b9e748d05d587af3"
icount=`ps -w|grep upgrade|grep -v grep|wc -l`
[ "$icount" -gt 0 ] && exit


localfsmd5=`md5sum  /tmp/fs.bin|awk  '{print $1}'`
localkernelmd5=`md5sum  /tmp/kernel.bin|awk  '{print $1}'`
localbootmd5=`md5sum  /tmp/bootcore.bin|awk  '{print $1}'`
localgphymd5=`md5sum  /tmp/gphy.bin|awk  '{print $1}'`
localubootmd5=`md5sum  /tmp/uboot.bin|awk  '{print $1}'`
if [ "$fsmd5" == "$localfsmd5" -a "$kernelmd5" == "$localkernelmd5" -a "$bootmd5" == "$localbootmd5" -a "$gphymd5" == "$localgphymd5" -a "$ubootmd5" == "$localubootmd5" ] ;then
echo "down firmware ok!write firmware,please wait..." 
mtd write /tmp/uboot.bin  uboot
mtd write /tmp/gphy.bin  gphyfirmware  
upgrade /tmp/bootcore.bin bootcore 0 1 
upgrade /tmp/fs.bin rootfs 0 1  
echo "write firmware ok,start write kernel,please wait..."  
upgrade /tmp/kernel.bin kernel 1 1 

uci set version.num.ver=V1.4 2>/dev/null
uci commit version  2>/dev/null
uci set system.sys.fw_ver=99.1.49.293
uci commit system
cp -f /rom/etc/config/schemeupgrade /etc/config/schemeupgrade
sleep 2
echo "upgrade ok!reboot..."   
reboot
else
echo "firmware md5 error !"   
fi



